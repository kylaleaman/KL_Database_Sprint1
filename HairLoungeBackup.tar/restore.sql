--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hairlounge;
--
-- Name: hairlounge; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE hairlounge WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE hairlounge OWNER TO postgres;

\connect hairlounge

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    addressid character varying(10) NOT NULL,
    streetadd character varying(100),
    city character varying(50),
    province character varying(50),
    country character varying(50),
    postalcode character varying(6)
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    appointmentid character varying(10) NOT NULL,
    date date,
    "time" time without time zone,
    stylistid character varying(10),
    clientid character varying(10),
    serviceid character varying(10)
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    categoryid character varying(10) NOT NULL,
    categoryname character varying(50)
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    clientid character varying(10) NOT NULL,
    clientname character varying(100),
    contactid character varying(10),
    addressid character varying(10),
    stylistid character varying(10)
);


ALTER TABLE public.client OWNER TO postgres;

--
-- Name: contactinfo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contactinfo (
    contactid character varying(10) NOT NULL,
    email character varying(100),
    phonenum character varying(12)
);


ALTER TABLE public.contactinfo OWNER TO postgres;

--
-- Name: payrate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payrate (
    payid character varying(10) NOT NULL,
    commission integer,
    hourpay integer
);


ALTER TABLE public.payrate OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    productid character varying(10) NOT NULL,
    productname character varying(100),
    serviceid character varying(10),
    supplierid character varying(10),
    numstock integer
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: retail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.retail (
    retailid character varying(10) NOT NULL,
    retailname character varying(100),
    productcost money,
    productprice money,
    numstock integer,
    supplierid character varying(10)
);


ALTER TABLE public.retail OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    serviceid character varying(10) NOT NULL,
    servicename character varying(100),
    serviceprice money,
    categoryid character varying(10),
    timespent integer
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: stylist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stylist (
    stylistid character varying(10) NOT NULL,
    stylistname character varying(100),
    contactid character varying(10),
    addressid character varying(10),
    categoryid character varying(10),
    payid character varying(10)
);


ALTER TABLE public.stylist OWNER TO postgres;

--
-- Name: supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier (
    supplierid character varying(10) NOT NULL,
    suppliername character varying(100),
    contactid character varying(10),
    salesrep character varying(100)
);


ALTER TABLE public.supplier OWNER TO postgres;

--
-- Name: tools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tools (
    toolid character varying(10) NOT NULL,
    toolname character varying(50),
    numstock integer,
    toolcost money,
    supplierid character varying(10)
);


ALTER TABLE public.tools OWNER TO postgres;

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (addressid, streetadd, city, province, country, postalcode) FROM stdin;
\.
COPY public.address (addressid, streetadd, city, province, country, postalcode) FROM '$$PATH$$/3670.dat';

--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (appointmentid, date, "time", stylistid, clientid, serviceid) FROM stdin;
\.
COPY public.appointments (appointmentid, date, "time", stylistid, clientid, serviceid) FROM '$$PATH$$/3680.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (categoryid, categoryname) FROM stdin;
\.
COPY public.category (categoryid, categoryname) FROM '$$PATH$$/3672.dat';

--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (clientid, clientname, contactid, addressid, stylistid) FROM stdin;
\.
COPY public.client (clientid, clientname, contactid, addressid, stylistid) FROM '$$PATH$$/3679.dat';

--
-- Data for Name: contactinfo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contactinfo (contactid, email, phonenum) FROM stdin;
\.
COPY public.contactinfo (contactid, email, phonenum) FROM '$$PATH$$/3669.dat';

--
-- Data for Name: payrate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payrate (payid, commission, hourpay) FROM stdin;
\.
COPY public.payrate (payid, commission, hourpay) FROM '$$PATH$$/3671.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (productid, productname, serviceid, supplierid, numstock) FROM stdin;
\.
COPY public.products (productid, productname, serviceid, supplierid, numstock) FROM '$$PATH$$/3677.dat';

--
-- Data for Name: retail; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.retail (retailid, retailname, productcost, productprice, numstock, supplierid) FROM stdin;
\.
COPY public.retail (retailid, retailname, productcost, productprice, numstock, supplierid) FROM '$$PATH$$/3674.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (serviceid, servicename, serviceprice, categoryid, timespent) FROM stdin;
\.
COPY public.services (serviceid, servicename, serviceprice, categoryid, timespent) FROM '$$PATH$$/3676.dat';

--
-- Data for Name: stylist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stylist (stylistid, stylistname, contactid, addressid, categoryid, payid) FROM stdin;
\.
COPY public.stylist (stylistid, stylistname, contactid, addressid, categoryid, payid) FROM '$$PATH$$/3678.dat';

--
-- Data for Name: supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier (supplierid, suppliername, contactid, salesrep) FROM stdin;
\.
COPY public.supplier (supplierid, suppliername, contactid, salesrep) FROM '$$PATH$$/3673.dat';

--
-- Data for Name: tools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tools (toolid, toolname, numstock, toolcost, supplierid) FROM stdin;
\.
COPY public.tools (toolid, toolname, numstock, toolcost, supplierid) FROM '$$PATH$$/3675.dat';

--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (addressid);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (appointmentid);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (categoryid);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (clientid);


--
-- Name: contactinfo contactinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contactinfo
    ADD CONSTRAINT contactinfo_pkey PRIMARY KEY (contactid);


--
-- Name: payrate payrate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payrate
    ADD CONSTRAINT payrate_pkey PRIMARY KEY (payid);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (productid);


--
-- Name: retail retail_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.retail
    ADD CONSTRAINT retail_pkey PRIMARY KEY (retailid);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (serviceid);


--
-- Name: stylist stylist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stylist
    ADD CONSTRAINT stylist_pkey PRIMARY KEY (stylistid);


--
-- Name: supplier supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_pkey PRIMARY KEY (supplierid);


--
-- Name: tools tools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_pkey PRIMARY KEY (toolid);


--
-- Name: appointments appointments_clientid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_clientid_fkey FOREIGN KEY (clientid) REFERENCES public.client(clientid);


--
-- Name: appointments appointments_serviceid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_serviceid_fkey FOREIGN KEY (serviceid) REFERENCES public.services(serviceid);


--
-- Name: appointments appointments_stylistid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_stylistid_fkey FOREIGN KEY (stylistid) REFERENCES public.stylist(stylistid);


--
-- Name: client client_addressid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_addressid_fkey FOREIGN KEY (addressid) REFERENCES public.address(addressid);


--
-- Name: client client_contactid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_contactid_fkey FOREIGN KEY (contactid) REFERENCES public.contactinfo(contactid);


--
-- Name: client client_stylistid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_stylistid_fkey FOREIGN KEY (stylistid) REFERENCES public.stylist(stylistid);


--
-- Name: products products_serviceid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_serviceid_fkey FOREIGN KEY (serviceid) REFERENCES public.services(serviceid);


--
-- Name: products products_supplierid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_supplierid_fkey FOREIGN KEY (supplierid) REFERENCES public.supplier(supplierid);


--
-- Name: retail retail_supplierid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.retail
    ADD CONSTRAINT retail_supplierid_fkey FOREIGN KEY (supplierid) REFERENCES public.supplier(supplierid);


--
-- Name: services services_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES public.category(categoryid);


--
-- Name: stylist stylist_addressid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stylist
    ADD CONSTRAINT stylist_addressid_fkey FOREIGN KEY (addressid) REFERENCES public.address(addressid);


--
-- Name: stylist stylist_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stylist
    ADD CONSTRAINT stylist_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES public.category(categoryid);


--
-- Name: stylist stylist_contactid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stylist
    ADD CONSTRAINT stylist_contactid_fkey FOREIGN KEY (contactid) REFERENCES public.contactinfo(contactid);


--
-- Name: stylist stylist_payid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stylist
    ADD CONSTRAINT stylist_payid_fkey FOREIGN KEY (payid) REFERENCES public.payrate(payid);


--
-- Name: supplier supplier_contactid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_contactid_fkey FOREIGN KEY (contactid) REFERENCES public.contactinfo(contactid);


--
-- Name: tools tools_supplierid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_supplierid_fkey FOREIGN KEY (supplierid) REFERENCES public.supplier(supplierid);


--
-- PostgreSQL database dump complete
--

